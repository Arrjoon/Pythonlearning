# Event Management System Python

### Features : ---
1. Create An Event
2. View Events
3. Book Ticket
4. View Ticket
5. Condition Check If Customer Already Buy Same Event Ticket
6. Condition Check if All Tickets are sold Out.
7. Show Overall Event Summary
